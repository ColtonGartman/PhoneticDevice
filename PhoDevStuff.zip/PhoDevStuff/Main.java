public class Main {

	public static void main (String[] args) {
		
		new Constructor();
		
	}
	
}

/*
 * To Do:
 * 
 *  1. Add in sounds
 *  2. Create/ find image library for a bunch of words
 *	3. Make resizable
 *	4. Make better
 *
 *
 *
 *
 *
 *
 *
 *	999. Make physical model
 *
 */