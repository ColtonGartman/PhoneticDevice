import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Constructor extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static int count = 0;
	
	private static int width = 1200;
	private static int height = width/ 2 + 100;
	private static int butwidth = (width - 15)/ 5;
	private static int butheight = (height - 34)/ 6;
	
	private static String wrdCrt;
	private static Color fontColor= new Color(0, 0, 0);
	
	private static JLabel wrdDis;
	private static JLabel wrdImage;
	
	private static JPanel panel;
	private static JPanel ImgBckGrnd;

	private static JButton aButton;
	private static JButton bButton;
	private static JButton cButton;
	private static JButton dButton;
	private static JButton eButton;
	private static JButton fButton;
	private static JButton gButton;
	private static JButton hButton;
	private static JButton iButton;
	private static JButton jButton;
	private static JButton kButton;
	private static JButton lButton;
	private static JButton mButton;
	private static JButton nButton;
	private static JButton oButton;
	private static JButton pButton;
	private static JButton qButton;
	private static JButton rButton;
	private static JButton sButton;
	private static JButton tButton;
	private static JButton uButton;
	private static JButton vButton;
	private static JButton wButton;
	private static JButton xButton;
	private static JButton yButton;
	private static JButton zButton;
	private static JButton wrdButton;
	
	Constructor() {
		
		//******************************************************************************
		// Setup for A-Z buttons and Create button
		//******************************************************************************
		
		aButton = new JButton("A");
		aButton.setBounds(0, 0, butwidth, butheight);
		aButton.setFocusable(false);
		aButton.addActionListener(e -> makeSoundA());
		aButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		aButton.setForeground(fontColor);
		aButton.setBackground(Color.RED);
		aButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		bButton = new JButton("B");
		bButton.setBounds(butwidth, 0, butwidth, butheight);
		bButton.setFocusable(false);
		bButton.addActionListener(e -> makeSoundB());
		bButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		bButton.setForeground(fontColor);
		bButton.setBackground(Color.ORANGE);
		bButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		cButton = new JButton("C");
		cButton.setBounds(butwidth * 2, 0, butwidth, butheight);
		cButton.setFocusable(false);
		cButton.addActionListener(e -> makeSoundC());
		cButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		cButton.setForeground(fontColor);
		cButton.setBackground(Color.YELLOW);
		cButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		dButton = new JButton("D");
		dButton.setBounds(butwidth * 3, 0, butwidth, butheight);
		dButton.setFocusable(false);
		dButton.addActionListener(e -> makeSoundD());
		dButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		dButton.setForeground(fontColor);
		dButton.setBackground(Color.GREEN);
		dButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		eButton = new JButton("E");
		eButton.setBounds(butwidth * 4, 0, butwidth, butheight);
		eButton.setFocusable(false);
		eButton.addActionListener(e -> makeSoundE());
		eButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		eButton.setForeground(fontColor);
		eButton.setBackground(Color.CYAN);
		eButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		fButton = new JButton("F");
		fButton.setBounds(0, butheight, butwidth, butheight);
		fButton.setFocusable(false);
		fButton.addActionListener(e -> makeSoundF());
		fButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		fButton.setForeground(fontColor);
		fButton.setBackground(Color.RED);
		fButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		gButton = new JButton("G");
		gButton.setBounds(butwidth, butheight, butwidth, butheight);
		gButton.setFocusable(false);
		gButton.addActionListener(e -> makeSoundG());
		gButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		gButton.setForeground(fontColor);
		gButton.setBackground(Color.ORANGE);
		gButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		hButton = new JButton("H");
		hButton.setBounds(butwidth * 2, butheight, butwidth, butheight);
		hButton.setFocusable(false);
		hButton.addActionListener(e -> makeSoundH());
		hButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		hButton.setForeground(fontColor);
		hButton.setBackground(Color.YELLOW);
		hButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		iButton = new JButton("I");
		iButton.setBounds(butwidth * 3, butheight, butwidth, butheight);
		iButton.setFocusable(false);
		iButton.addActionListener(e -> makeSoundI());
		iButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		iButton.setForeground(fontColor);
		iButton.setBackground(Color.GREEN);
		iButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		jButton = new JButton("J");
		jButton.setBounds(butwidth * 4, butheight, butwidth, butheight);
		jButton.setFocusable(false);
		jButton.addActionListener(e -> makeSoundJ());
		jButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		jButton.setForeground(fontColor);
		jButton.setBackground(Color.CYAN);
		jButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		kButton = new JButton("K");
		kButton.setBounds(0, butheight * 2, butwidth, butheight);
		kButton.setFocusable(false);
		kButton.addActionListener(e -> makeSoundK());
		kButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		kButton.setForeground(fontColor);
		kButton.setBackground(Color.RED);
		kButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		lButton = new JButton("L");
		lButton.setBounds(butwidth, butheight * 2, butwidth, butheight);
		lButton.setFocusable(false);
		lButton.addActionListener(e -> makeSoundL());
		lButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		lButton.setForeground(fontColor);
		lButton.setBackground(Color.ORANGE);
		lButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		mButton = new JButton("M");
		mButton.setBounds(butwidth * 2, butheight * 2, butwidth, butheight);
		mButton.setFocusable(false);
		mButton.addActionListener(e -> makeSoundM());
		mButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		mButton.setForeground(fontColor);
		mButton.setBackground(Color.YELLOW);
		mButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		nButton = new JButton("N");
		nButton.setBounds(butwidth * 3, butheight * 2, butwidth, butheight);
		nButton.setFocusable(false);
		nButton.addActionListener(e -> makeSoundN());
		nButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		nButton.setForeground(fontColor);
		nButton.setBackground(Color.GREEN);
		nButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		oButton = new JButton("O");
		oButton.setBounds(butwidth * 4, butheight * 2, butwidth, butheight);
		oButton.setFocusable(false);
		oButton.addActionListener(e -> makeSoundO());
		oButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		oButton.setForeground(fontColor);
		oButton.setBackground(Color.CYAN);
		oButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		pButton = new JButton("P");
		pButton.setBounds(0, butheight * 3, butwidth, butheight);
		pButton.setFocusable(false);
		pButton.addActionListener(e -> makeSoundP());
		pButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		pButton.setForeground(fontColor);
		pButton.setBackground(Color.RED);
		pButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		qButton = new JButton("Q");
		qButton.setBounds(butwidth, butheight * 3, butwidth, butheight);
		qButton.setFocusable(false);
		qButton.addActionListener(e -> makeSoundQ());
		qButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		qButton.setForeground(fontColor);
		qButton.setBackground(Color.ORANGE);
		qButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		rButton = new JButton("R");
		rButton.setBounds(butwidth * 2, butheight * 3, butwidth, butheight);
		rButton.setFocusable(false);
		rButton.addActionListener(e -> makeSoundR());
		rButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		rButton.setForeground(fontColor);
		rButton.setBackground(Color.YELLOW);
		rButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		sButton = new JButton("S");
		sButton.setBounds(butwidth * 3, butheight * 3, butwidth, butheight);
		sButton.setFocusable(false);
		sButton.addActionListener(e -> makeSoundS());
		sButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		sButton.setForeground(fontColor);
		sButton.setBackground(Color.GREEN);
		sButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		tButton = new JButton("T");
		tButton.setBounds(butwidth * 4, butheight * 3, butwidth, butheight);
		tButton.setFocusable(false);
		tButton.addActionListener(e -> makeSoundT());
		tButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		tButton.setForeground(fontColor);
		tButton.setBackground(Color.CYAN);
		tButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		uButton = new JButton("U");
		uButton.setBounds(0, butheight * 4, butwidth, butheight);
		uButton.setFocusable(false);
		uButton.addActionListener(e -> makeSoundU());
		uButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		uButton.setForeground(fontColor);
		uButton.setBackground(Color.RED);
		uButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		vButton = new JButton("V");
		vButton.setBounds(butwidth, butheight * 4, butwidth, butheight);
		vButton.setFocusable(false);
		vButton.addActionListener(e -> makeSoundV());
		vButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		vButton.setForeground(fontColor);
		vButton.setBackground(Color.ORANGE);
		vButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		wButton = new JButton("W");
		wButton.setBounds(butwidth * 2, butheight * 4, butwidth, butheight);
		wButton.setFocusable(false);
		wButton.addActionListener(e -> makeSoundW());
		wButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		wButton.setForeground(fontColor);
		wButton.setBackground(Color.YELLOW);
		wButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		xButton = new JButton("X");
		xButton.setBounds(butwidth * 3, butheight * 4, butwidth, butheight);
		xButton.setFocusable(false);
		xButton.addActionListener(e -> makeSoundX());
		xButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		xButton.setForeground(fontColor);
		xButton.setBackground(Color.GREEN);
		xButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));

		yButton = new JButton("Y");
		yButton.setBounds(butwidth * 4, butheight * 4, butwidth, butheight);
		yButton.setFocusable(false);
		yButton.addActionListener(e -> makeSoundY());
		yButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		yButton.setForeground(fontColor);
		yButton.setBackground(Color.CYAN);
		yButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		zButton = new JButton("Z");
		zButton.setBounds(0, butheight * 5, butwidth, butheight);
		zButton.setFocusable(false);
		zButton.addActionListener(e -> makeSoundZ());
		zButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		zButton.setForeground(fontColor);
		zButton.setBackground(Color.RED);
		zButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		wrdButton = new JButton("Create");
		wrdButton.setBounds(butwidth, butheight * 5, butwidth + butwidth/ 2, butheight);
		wrdButton.setFocusable(false);
		wrdButton.addActionListener(e -> makeWord());
		wrdButton.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		wrdButton.setForeground(fontColor);
		wrdButton.setBackground(Color.CYAN);
		wrdButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		//******************************************************************************
		// Setup for Image display
		// Images should be 100x100, can't be bothered to auto resize
		//******************************************************************************
		
		wrdImage = new JLabel(" ");
		wrdImage.setFocusable(false);
		wrdImage.setIconTextGap(-butwidth/ 2 + butwidth/ 10);
		wrdImage.setHorizontalAlignment(JLabel.CENTER);
		wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/QuestionMark.png")));
		wrdImage.setBounds(butwidth * 2 + butwidth / 2, butheight * 5, butwidth / 2 + butwidth/ 10, butheight);
		
		ImgBckGrnd = new JPanel();
		ImgBckGrnd.setBounds(butwidth * 2 + butwidth / 2, butheight * 5, butwidth / 2 + butwidth/ 10, butheight);
		ImgBckGrnd.setBackground(Color.BLACK);
		
		//******************************************************************************
		// Setup for word/ letter display
		//******************************************************************************
		
		wrdDis = new JLabel("Try Me", SwingConstants.CENTER);
		wrdDis.setBounds(butwidth * 3, butheight * 5, butwidth * 2, butheight);
		wrdDis.setFocusable(false);
		wrdDis.setFont(new Font("Times New Roman", Font.BOLD, butheight/ 2));
		wrdDis.setForeground(Color.RED);
		wrdDis.setBackground(Color.BLACK);
		wrdDis.setBorder(BorderFactory.createLineBorder(Color.BLACK, 3));
		
		panel = new JPanel();
		panel.setBounds(butwidth * 3, butheight * 5, butwidth * 2, butheight);
		panel.setBackground(Color.BLACK);
		
		//******************************************************************************
		// Setup for frame, then additions to frame.
		//******************************************************************************
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(width, height);
		this.setResizable(false);
		this.setLayout(null);
		this.setVisible(true);
		
		this.add(aButton);
		this.add(bButton);
		this.add(cButton);
		this.add(dButton);
		this.add(eButton);
		this.add(fButton);
		this.add(gButton);
		this.add(hButton);
		this.add(iButton);
		this.add(jButton);
		this.add(kButton);
		this.add(lButton);
		this.add(mButton);
		this.add(nButton);
		this.add(oButton);
		this.add(pButton);
		this.add(qButton);
		this.add(rButton);
		this.add(sButton);
		this.add(tButton);
		this.add(uButton);
		this.add(vButton);
		this.add(wButton);
		this.add(xButton);
		this.add(yButton);
		this.add(zButton);
		this.add(wrdImage);
		this.add(ImgBckGrnd);
		this.add(wrdButton);
		this.add(wrdDis);
		this.add(panel);
		
	}
	
	//******************************************************************************
	// Function for create button
	//******************************************************************************
	
	private static void makeWord() {
		
		// When pressed clears wrdCrt
		// If count is even leaves wrdCrt shown until
		// wrdCrt is updated and displays image if available.
		
		count++;
		if (count % 2 == 0) {
			new DisplayIm(wrdCrt, wrdImage);
			wrdCrt = "";
		} else {
			wrdCrt = "";
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	//******************************************************************************
	// Functions for each of the letter buttons.
	//
	// When count is even sets wrdCrt to letter
	// When odd adds letter to wrdCrt.
	//******************************************************************************
	
	private static void makeSoundA() {
		
		if (count % 2 == 0) {
			wrdCrt = "A";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'A';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundB() {
		
		if (count % 2 == 0) {
			wrdCrt = "B";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'B';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundC() {
		
		if (count % 2 == 0) {
			wrdCrt = "C";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'C';
			wrdDis.setText(wrdCrt);
		}
		
	}

	private static void makeSoundD() {
	
		if (count % 2 == 0) {
			wrdCrt = "D";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'D';
			wrdDis.setText(wrdCrt);
		}
	
	}

	private static void makeSoundE() {
	
		if (count % 2 == 0) {
			wrdCrt = "E";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'E';
			wrdDis.setText(wrdCrt);
		}
	
	}

	private static void makeSoundF() {
	
		if (count % 2 == 0) {
			wrdCrt = "F";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'F';
			wrdDis.setText(wrdCrt);
		}
	
	}

	private static void makeSoundG() {
	
		if (count % 2 == 0) {
			wrdCrt = "G";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'G';
			wrdDis.setText(wrdCrt);
		}
	
	}
	
	private static void makeSoundH() {
		
		if (count % 2 == 0) {
			wrdCrt = "H";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'H';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundI() {
		
		if (count % 2 == 0) {
			wrdCrt = "I";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'I';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundJ() {
		
		if (count % 2 == 0) {
			wrdCrt = "J";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'J';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundK() {
		
		if (count % 2 == 0) {
			wrdCrt = "K";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'K';
			wrdDis.setText(wrdCrt);
		}
		
	}

	private static void makeSoundL() {
		
		if (count % 2 == 0) {
			wrdCrt = "L";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'L';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundM() {
		
		if (count % 2 == 0) {
			wrdCrt = "M";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'M';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundN() {
		
		if (count % 2 == 0) {
			wrdCrt = "N";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'N';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundO() {
		
		if (count % 2 == 0) {
			wrdCrt = "O";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'O';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundP() {
		
		if (count % 2 == 0) {
			wrdCrt = "P";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'P';
			wrdDis.setText(wrdCrt);
		}
		
	}

	private static void makeSoundQ() {
		
		if (count % 2 == 0) {
			wrdCrt = "Q";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'Q';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundR() {
		
		if (count % 2 == 0) {
			wrdCrt = "R";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'R';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundS() {
		
		if (count % 2 == 0) {
			wrdCrt = "S";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'S';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundT() {
		
		if (count % 2 == 0) {
			wrdCrt = "T";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'T';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundU() {
		
		if (count % 2 == 0) {
			wrdCrt = "U";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'U';
			wrdDis.setText(wrdCrt);
		}
		
	}

	private static void makeSoundV() {
		
		if (count % 2 == 0) {
			wrdCrt = "V";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'V';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundW() {
		
		if (count % 2 == 0) {
			wrdCrt = "W";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'W';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundX() {
		
		if (count % 2 == 0) {
			wrdCrt = "X";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'X';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundY() {
		
		if (count % 2 == 0) {
			wrdCrt = "Y";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'Y';
			wrdDis.setText(wrdCrt);
		}
		
	}
	
	private static void makeSoundZ() {
		
		if (count % 2 == 0) {
			wrdCrt = "Z";
			wrdDis.setText(wrdCrt);
		} else {
			wrdCrt += 'Z';
			wrdDis.setText(wrdCrt);
		}
		
	}
}
