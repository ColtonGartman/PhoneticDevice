import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class DisplayIm {

	DisplayIm (String wrdCrt, JLabel wrdImage) {
		
		//******************************************************************************
		// Storage for all of the images
		// All should be 100x100 w/o backgrounds
		// Useful websites:
		//      https://imageresizer.com/
		//      https://www.remove.bg/upload
		//******************************************************************************
		
		switch (wrdCrt) {
		
		case ("CAT"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/catPic.png")));
		break;
		case ("DOG"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/dog.png")));
		break;
		case ("TREE"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/tree.png")));
		break;
		case ("MOM"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/mom.png")));
		break;
		case ("DAD"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/dad.png")));
		break;
		case ("CLOUD"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/cloud.png")));
		break;
		case ("SUN"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/sun.png")));
		break;
		case ("FOOD"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/food.png")));
		break;
		case ("DRINK"): wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/drink.png")));
		break;
		default: wrdImage.setIcon(new ImageIcon(getClass().getResource("Images/QuestionMark.png")));
		
		}
		
	}
}
